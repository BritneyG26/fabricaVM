class FabricaChocolate:
    def __init__(self):
        self.cacao = 1000  #kg
        self.leche = 1000  #kg
        self.azucar= 500  #kg
        self.manteca_cacao= 1000 #kg
        self.ingredientes_adicionales =500  #kg
        self.chocolate_producido = 0  # kg
        self.log = []

    def añadir_linea_log(self, linea):
        self.log.append(linea)

    def procesar_instruccion(self, linea):
        partes = linea.lower().strip().split()
        if "añadir" in linea.lower():
            cantidad = float(partes[1].replace("kg", ""))
            ingrediente = " ".join(partes[2:])
            self.añadir_ingrediente(cantidad, ingrediente)
        elif "crear" in linea.lower():
            self.mezclar_ingredientes()
        elif "cantidad:" in linea.lower():
            self.chocolate_producido += float(partes[1])

    def añadir_ingrediente(self, cantidad, ingrediente):
        if "cacao en polvo" in ingrediente:
            if self.cacao >= cantidad:
                self.cacao -= cantidad
                self.añadir_linea_log(f"Añadiendo {cantidad}kg de cacao en polvo")
            else:
                self.añadir_linea_log("Error")
        elif "leche en polvo" in ingrediente:
            if self.leche >= cantidad:
                self.leche -= cantidad
                self.añadir_linea_log(f"Añadiendo {cantidad}kg de leche en polvo")
            else:
                self.añadir_linea_log("Error")
        elif "azúcar" in ingrediente:
            if self.azucar >= cantidad:
                self.azucar -= cantidad
                self.añadir_linea_log(f"Añadiendo {cantidad}kg de azúcar")
            else:
                self.añadir_linea_log("Error")
        elif "manteca de cacao" in ingrediente:
            if self.manteca_cacao >= cantidad:
                self.manteca_cacao -= cantidad
                self.añadir_linea_log(f"Añadiendo {cantidad}kg de manteca de cacao\n")
            else:
                self.añadir_linea_log("Error")        
        else:
            if self.ingredientes_adicionales >= cantidad:
                self.ingredientes_adicionales -= cantidad
                self.añadir_linea_log(f"Añadiendo {cantidad}kg de {ingrediente}")
            else:
                self.añadir_linea_log(f"Error")

    def mezclar_ingredientes(self):
        self.añadir_linea_log("Mezclando ingredientes...\n")
        self.añadir_linea_log("¡Chocolate listo!\n")

    def ejecutar(self, archivo_instrucciones):
        #iniciar máquina
        self.añadir_linea_log("Máquina encendida\n")
        self.añadir_linea_log("Iniciando máquina...\n")
        self.añadir_linea_log(f"Cacao en polvo disponible: {self.cacao}kg")
        self.añadir_linea_log(f"Leche en polvo disponible: {self.leche}kg")
        self.añadir_linea_log(f"Azúcar disponible: {self.azucar}kg")
        self.añadir_linea_log(f"Manteca de cacao disponible: {self.manteca_cacao}kg")
        self.añadir_linea_log("Ingredientes adicionales (almendras, avellanas, fresas, naranja, galletas): "
                             f"{self.ingredientes_adicionales}kg")
        self.añadir_linea_log("===========================\n")

        #leer y procesar instrucciones
        with open(archivo_instrucciones, 'r', encoding='utf-8') as f:
            instrucciones = f.read().splitlines()

        instrucciones_originales = instrucciones.copy()

        #Procesar cada instrucción
        for instruccion in instrucciones:
            if instruccion.strip():
                self.procesar_instruccion(instruccion)

        #Lo que queda luego
        self.añadir_linea_log("==========================")
        self.añadir_linea_log(f"Cacao en polvo disponible: {self.cacao}kg")
        self.añadir_linea_log(f"Leche en polvo disponible: {self.leche}kg")
        self.añadir_linea_log(f"Azúcar disponible: {self.azucar}kg")
        self.añadir_linea_log(f"Manteca de cacao: {self.azucar}kg")
        self.añadir_linea_log(f"Ingredientes adicionales: {self.ingredientes_adicionales}kg\n")
        self.añadir_linea_log(f"Chocolate total producido: {self.chocolate_producido}kg\n")
        self.añadir_linea_log("Apagando máquina...\n")
        self.añadir_linea_log("Máquina apagada")

    
        with open(archivo_instrucciones, 'w', encoding='utf-8') as f:
            for instruccion in instrucciones_originales:
                f.write(instruccion + '\n')
            f.write('\n') 
            for linea in self.log:
                f.write(linea + '\n')

#Ejemplo de uso
if __name__ == "__main__":
    fabrica = FabricaChocolate()
    fabrica.ejecutar("instrucciones.txt")




